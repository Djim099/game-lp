/* ============================================================
   Once Human — Landing Page · app.js
   Conversion-optimised static JS (no framework required)
   ============================================================ */

/* ----------------------------------------------------------
   1. CONFIG OBJECT — edit these values before going live
   ---------------------------------------------------------- */
const LP_CONFIG = {
  /* Asset base (trailing slash) */
  asset_base_url: "https://cdn.example.com/oncehuman/",

  /* Hero media */
  hero_video_mp4:   "https://cdn.example.com/oncehuman/hero-loop.mp4",
  hero_video_webm:  "",   // optional WebM for smaller file size
  hero_poster_webp: "https://cdn.example.com/oncehuman/hero-poster.webp",

  /* Screenshots (provide all four srcset widths per shot) */
  screenshot_1_webp: "https://cdn.example.com/oncehuman/shot-threat.webp",
  screenshot_2_webp: "https://cdn.example.com/oncehuman/shot-territory.webp",
  screenshot_3_webp: "https://cdn.example.com/oncehuman/shot-crafting.webp",

  /* --- AFFILIATE / TRACKING LINKS ---
     Replace affiliate_base_link with your network tracking URL.
     The page will append ?subid=<click_id>&variant_id=<variant> + utm_* params.
     If the affiliate link is unavailable, steam_fallback_link is used.

     AFFILIATE POSTBACK NOTE:
     This file does NOT implement a server-side postback; that must be configured
     in your affiliate network dashboard. The affiliate_click_id_param below is
     the query-string key your network expects for the click/sub ID.
  */
  affiliate_base_link:      "https://YOUR_TRACKING_DOMAIN/click?offer=oncehuman&dest=steam",
  steam_fallback_link:      "https://store.steampowered.com/app/2139460/Once_Human/",
  /* ← CHANGE THIS to the param name your affiliate network requires (e.g. "s1", "clickid", "aff_sub") */
  affiliate_click_id_param: "subid",

  /* Localisation */
  default_language:    "en-GB",
  supported_languages: ["en-GB", "de-DE", "fr-FR"],

  /* A/B variant — can be overridden by ?variant_id= query param
     Naming scheme: H<headline>_<hook>_<media>_CTA<n>
     e.g. H1_FEAR_VID_CTA1 | H2_POWER_IMG_CTA2 | H3_OWNER_VID_CTA3 */
  variant_id: "H1_FEAR_VID_CTA1",

  /* Feature flags */
  debug:      true,   // set false in production
  enable_qr:  false,  // QR code on non-Windows fallback

  /* A/B hypothesis toggles (document in README) */
  hypotheses: {
    hook_angle:          "fear",       // "fear" | "power" | "ownership"
    hero_media:          "video",      // "video" | "poster"
    cta_copy_index:      0,            // 0–5 → maps to CTA_VARIANTS array
    strip_position:      "above_fold", // "above_fold" | "below_scroll"
    requirements_visible:"mini_card",  // "mini_card" | "faq_only"
  },
};

/* ----------------------------------------------------------
   2. COPY VARIANTS (EN mandatory; DE/FR stubs provided)
   ---------------------------------------------------------- */
const COPY = {
  "en-GB": {
    headlines: [
      "Survive a World That's Already Dead",                    // H1 — Fear
      "The Contamination Has a Name. Now So Do You.",           // H2 — Curiosity
      "Build. Hunt. Endure. This Is Once Human.",               // H3 — Ownership
      "Your Sanity Is the Only Currency That Matters",          // H4 — Psychological
      "The Stardust Changed Everything. Can You Survive It?",   // H5 — Lore hook
      "Claim Your Territory Before Someone Else Does",          // H6 — Competitive
    ],
    subheads: [
      "A free-to-play survival game where contamination, creatures, and other players will test everything you have.",
      "Explore a ruined open world, build your base, and fight back against forces you don't fully understand.",
      "Craft weapons from blueprints, relocate your territory, and uncover what Stardust has done to the world.",
      "Your sanity shifts with the world around you. Stay sharp, stay alive, and build something worth defending.",
      "Once Human is a free-to-play PC survival game with co-op, base-building, and a world corrupted by Stardust.",
      "Stake your claim in a contaminated open world. Build, fight, and survive — alone or with others.",
    ],
    ctas: [
      "Play on Steam (Windows)",
      "Install via Steam — Free",
      "Start Survival — Free to Play",
      "Get Once Human on Steam",
      "Play Free on Steam",
      "Download & Survive — Free",
    ],
    microcopy: [
      "Opens on Steam · Windows 10/11 required · Up to ~90 GB free space · Online play · Optional in-game purchases.",
      "Free to install on Steam · Windows PC only · Up to ~90 GB storage · Broadband required.",
      "Launches Steam · Windows 10/11 · ~90 GB · Online · Free with optional purchases.",
      "Opens on Steam in a new tab · Windows only · Up to ~90 GB free · Online required.",
      "Steam required · Windows 10/11 · Up to ~90 GB · In-game purchases available.",
      "Free on Steam · Windows PC · ~90 GB storage · Online play · Optional purchases.",
    ],
    faqs: [
      {
        id: "faq_free",
        q: "Is it free to play?",
        a: "Yes. Once Human is free to download and play on Steam. Optional in-game purchases are available, including items that may use chance-based mechanics. You are never required to spend money to enjoy the game.",
      },
      {
        id: "faq_steam",
        q: "Do I need Steam?",
        a: "Yes. Once Human is distributed exclusively via Steam. Clicking the button above will take you to the Steam store page where you can install it for free.",
      },
      {
        id: "faq_windows",
        q: "Is it Windows only?",
        a: "Yes. Once Human is a Windows PC game (Windows 10 or 11 required). It is not available on consoles, Mac, or mobile at this time.",
      },
      {
        id: "faq_storage",
        q: "How much storage space do I need?",
        a: "We recommend having up to approximately 90 GB of free space available. An SSD is recommended for faster load times.",
      },
      {
        id: "faq_online",
        q: "Is it online? Can I play with friends?",
        a: "Yes. Once Human requires a broadband internet connection and features online co-op, PvP options, and in-game chat. You'll be sharing a world with other players.",
      },
      {
        id: "faq_purchases",
        q: "Are there in-game purchases?",
        a: "Yes. Once Human includes optional in-game purchases. Some purchasable items may involve chance-based elements (loot boxes or similar mechanics). All purchases are optional and the game is fully playable without spending.",
      },
    ],
    nav: { lang_label: "Language", eligibility: "Offer available in selected countries · Windows PC only" },
    steps: [
      { n: "01", title: "Open on Steam", desc: "Click the button to visit the Steam store page." },
      { n: "02", title: "Install on Windows", desc: "Download and install the free Windows client." },
      { n: "03", title: "Launch → Create Your Role", desc: "Start the game and complete role creation." },
    ],
    steps_note: "Your progress starts after you create your in-game role.",
    bullets: [
      {
        icon: "☣",
        title: "Survive a contaminated world",
        body: "Stardust has rewritten the rules. Your sanity is a resource — guard it.",
      },
      {
        icon: "🏗",
        title: "Build and relocate your territory",
        body: "Claim land, construct your base, and move it when the world shifts.",
      },
      {
        icon: "🔩",
        title: "Craft and customise your weapons",
        body: "Combine blueprints and parts to build weapons that match your playstyle.",
      },
    ],
    modules: [
      {
        id: "mod_hook",
        eyebrow: "The World After",
        headline: "Stardust Has Already Won",
        lines: [
          "The contamination didn't end the world. It changed it.",
          "Mutated creatures. Fractured landscapes. A sanity meter that doesn't lie.",
          "You arrive after the collapse. What you do next is up to you.",
        ],
      },
      {
        id: "mod_curiosity",
        eyebrow: "Something's Out There",
        headline: "Not Everything Was Human First",
        lines: [
          "The creatures you'll encounter aren't random encounters — they're guardians of something.",
          "Boss fights aren't just damage checks. They're puzzles wrapped in dread.",
          "Learn their patterns or become part of the contamination.",
        ],
      },
      {
        id: "mod_solution",
        eyebrow: "You Are the Variable",
        headline: "Survive, Build, Claim, Repeat",
        lines: [
          "Weapons built from parts you found. A base placed exactly where you decided.",
          "Co-op squads or solo runs — the contaminated world doesn't care either way.",
          "Your role is what you make it. Create it before someone else fills the gap.",
        ],
      },
    ],
    first_session: [
      "Explore your starting area and gather your first resources",
      "Establish a basic shelter before nightfall changes the threat level",
      "Encounter your first deviation — and decide how you'll fight it",
    ],
    requirements: [
      { label: "OS", value: "Windows 10 / 11" },
      { label: "Storage", value: "Up to ~90 GB free (SSD recommended)" },
      { label: "Connection", value: "Broadband internet required" },
      { label: "Platform", value: "Steam (free account)" },
    ],
    fallback_title: "PC (Windows) Only",
    fallback_body:  "Once Human requires Windows 10 or 11. Switch to your Windows PC to play.",
    fallback_copy_btn: "Copy Link",
    fallback_qr_btn:   "Show QR Code",
    geo_block_title: "Check Your Eligibility",
    geo_block_body:  "This offer is available in selected countries. Please confirm your location:",
    geo_select_placeholder: "Select your country…",
    geo_confirm_btn: "Confirm & Continue",
    gallery_alt: [
      "Once Human — creature threat scale with player silhouette",
      "Once Human — territory and base-building overview",
      "Once Human — weapon crafting and customisation",
    ],
  },

  "de-DE": {
    headlines: [
      "Überlebe eine Welt, die schon tot ist",
      "Die Kontamination hat einen Namen. Jetzt du auch.",
      "Bauen. Jagen. Durchhalten. Das ist Once Human.",
      "Deine Vernunft ist die einzige Währung, die zählt",
      "Stardust hat alles verändert. Kannst du überleben?",
      "Beanspruche dein Territorium, bevor es jemand anderes tut",
    ],
    subheads: [
      "Ein kostenloses Survival-Spiel, in dem Kontamination, Kreaturen und andere Spieler alles fordern.",
      "Erkunde eine verfallene offene Welt, baue deine Basis und kämpfe zurück.",
      "Fertige Waffen aus Bauplänen, verlagere dein Territorium und enthülle, was Stardust angerichtet hat.",
      "Deine Vernunft verschiebt sich mit der Welt. Bleib scharf, bleib am Leben.",
      "Once Human ist ein kostenloses PC-Survival-Spiel mit Co-op, Basisbau und einer von Stardust korrumpierten Welt.",
      "Beanspruche ein kontaminiertes Gebiet. Baue, kämpfe und überlebe — allein oder mit anderen.",
    ],
    ctas: [
      "Auf Steam spielen (Windows)",
      "Via Steam installieren — Kostenlos",
      "Überleben starten — Kostenlos spielen",
      "Once Human auf Steam holen",
      "Kostenlos auf Steam spielen",
      "Herunterladen & überleben — Kostenlos",
    ],
    microcopy: [
      "Öffnet Steam · Windows 10/11 erforderlich · Bis zu ~90 GB freier Speicher · Online-Spiel · Optionale In-Game-Käufe.",
      "Kostenlos auf Steam installieren · Nur Windows-PC · Bis zu ~90 GB Speicher · Breitband erforderlich.",
      "Startet Steam · Windows 10/11 · ~90 GB · Online · Kostenlos mit optionalen Käufen.",
      "Öffnet Steam in einem neuen Tab · Nur Windows · Bis zu ~90 GB frei · Online erforderlich.",
      "Steam erforderlich · Windows 10/11 · Bis zu ~90 GB · In-Game-Käufe verfügbar.",
      "Kostenlos auf Steam · Windows-PC · ~90 GB Speicher · Online-Spiel · Optionale Käufe.",
    ],
    // faqs, steps etc. use en-GB as fallback — see getT()
  },

  "fr-FR": {
    headlines: [
      "Survivre dans un monde déjà mort",
      "La contamination a un nom. Vous aussi maintenant.",
      "Construire. Chasser. Endurer. C'est Once Human.",
      "Votre sanité est la seule monnaie qui compte",
      "Le Stardust a tout changé. Pouvez-vous survivre ?",
      "Revendiquez votre territoire avant que quelqu'un d'autre ne le fasse",
    ],
    subheads: [
      "Un jeu de survie gratuit où la contamination, les créatures et les autres joueurs mettront tout à l'épreuve.",
      "Explorez un monde ouvert en ruine, construisez votre base et combattez des forces que vous ne comprenez pas.",
      "Fabriquez des armes, déplacez votre territoire et découvrez ce que le Stardust a fait au monde.",
      "Votre sanité évolue avec le monde. Restez alerte, restez en vie.",
      "Once Human est un jeu de survie PC gratuit avec co-op, construction de base et un monde corrompu par le Stardust.",
      "Revendiquez un monde contaminé. Construisez, combattez et survivez — seul ou avec d'autres.",
    ],
    ctas: [
      "Jouer sur Steam (Windows)",
      "Installer via Steam — Gratuit",
      "Commencer la survie — Gratuit",
      "Obtenir Once Human sur Steam",
      "Jouer gratuitement sur Steam",
      "Télécharger et survivre — Gratuit",
    ],
    microcopy: [
      "Ouvre Steam · Windows 10/11 requis · Jusqu'à ~90 Go d'espace libre · Jeu en ligne · Achats optionnels dans le jeu.",
      "Installation gratuite sur Steam · PC Windows uniquement · Jusqu'à ~90 Go · Haut débit requis.",
      "Lance Steam · Windows 10/11 · ~90 Go · En ligne · Gratuit avec achats optionnels.",
      "Ouvre Steam dans un nouvel onglet · Windows uniquement · ~90 Go · Connexion requise.",
      "Steam requis · Windows 10/11 · Jusqu'à ~90 Go · Achats dans le jeu disponibles.",
      "Gratuit sur Steam · PC Windows · ~90 Go · Jeu en ligne · Achats optionnels.",
    ],
  },
};

/* ----------------------------------------------------------
   3. GEO / OS GATING
   ---------------------------------------------------------- */
const ALLOWED_GEOS = ["DE","FR","GB","AU","NL","AT","NO","CH","NZ","CA","US"];

const GEO_NAMES = {
  DE:"Germany", FR:"France", GB:"United Kingdom", AU:"Australia",
  NL:"Netherlands", AT:"Austria", NO:"Norway", CH:"Switzerland",
  NZ:"New Zealand", CA:"Canada", US:"United States",
};

function detectGeo() {
  // Priority 1: meta tag injected by server
  const metaTag = document.querySelector('meta[name="x-geo-country"]');
  if (metaTag) {
    const c = metaTag.getAttribute("content");
    if (c && c !== "__GEO_COUNTRY__") return c.toUpperCase();
  }
  // Priority 2: window variable injected before this script
  if (window.__GEO_COUNTRY && window.__GEO_COUNTRY !== "__GEO_COUNTRY__") {
    return String(window.__GEO_COUNTRY).toUpperCase();
  }
  // Priority 3: localStorage cache from previous manual selection
  const cached = localStorage.getItem("lp_geo");
  if (cached) return cached.toUpperCase();
  return null; // unknown → require manual selection
}

function detectOS() {
  // Prefer modern API
  if (navigator.userAgentData && navigator.userAgentData.platform) {
    const plat = navigator.userAgentData.platform.toLowerCase();
    if (plat.includes("win")) return "windows";
    if (plat.includes("mac")) return "mac";
    if (plat.includes("android") || plat.includes("linux")) return "linux";
    return plat;
  }
  // Fallback UA sniff
  const ua = navigator.userAgent.toLowerCase();
  if (ua.includes("windows")) return "windows";
  if (ua.includes("android")) return "android";
  if (ua.includes("iphone") || ua.includes("ipad")) return "ios";
  if (ua.includes("mac")) return "mac";
  if (ua.includes("linux")) return "linux";
  return "unknown";
}

/* ----------------------------------------------------------
   4. UTM + AFFILIATE LINK BUILDER
   ---------------------------------------------------------- */
function buildSteamLink(variantId) {
  const params = new URLSearchParams(window.location.search);
  const utms = {};
  for (const [k, v] of params.entries()) {
    if (k.startsWith("utm_")) utms[k] = v;
  }

  /* ← AFFILIATE CLICK ID: read from URL param named after config value.
     Your network typically passes this in the inbound click URL.
     Common param names: subid, clickid, s1, aff_sub, tid
     Change LP_CONFIG.affiliate_click_id_param to match your network. */
  const clickId = params.get(LP_CONFIG.affiliate_click_id_param) || "";

  let base = LP_CONFIG.affiliate_base_link || LP_CONFIG.steam_fallback_link;

  // Append utm_ params
  for (const [k, v] of Object.entries(utms)) {
    base += `&${encodeURIComponent(k)}=${encodeURIComponent(v)}`;
  }

  // Append affiliate click ID
  if (clickId) {
    /* ← THIS IS WHERE THE AFFILIATE CLICK / SUB ID IS APPENDED */
    base += `&${LP_CONFIG.affiliate_click_id_param}=${encodeURIComponent(clickId)}`;
  }

  // Append variant ID for tracking
  base += `&variant_id=${encodeURIComponent(variantId)}`;

  return base;
}

/* ----------------------------------------------------------
   5. EVENT EMITTER (no external trackers)
   ---------------------------------------------------------- */
window.dataLayer = window.dataLayer || [];

function emit(eventName, detail = {}) {
  const payload = { event: eventName, ts: Date.now(), ...detail };
  window.dataLayer.push(payload);
  document.dispatchEvent(new CustomEvent("lp_event", { detail: payload }));
  if (LP_CONFIG.debug) console.info("[LP]", eventName, payload);
}

/* ----------------------------------------------------------
   6. LANGUAGE SYSTEM
   ---------------------------------------------------------- */
let currentLang = LP_CONFIG.default_language;

function getT(key) {
  const lang = COPY[currentLang] || COPY["en-GB"];
  const fallback = COPY["en-GB"];
  // Resolve dot-notation key (e.g. "nav.lang_label")
  const keys = key.split(".");
  let val = lang;
  let fb  = fallback;
  for (const k of keys) {
    val = val?.[k];
    fb  = fb?.[k];
  }
  return val ?? fb ?? key;
}

function setLanguage(lang) {
  if (!LP_CONFIG.supported_languages.includes(lang)) lang = LP_CONFIG.default_language;
  currentLang = lang;
  localStorage.setItem("lp_lang", lang);
  document.documentElement.lang = lang;
  renderCopy();
  document.querySelectorAll(".lang-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
    btn.setAttribute("aria-pressed", btn.dataset.lang === lang);
  });
}

/* ----------------------------------------------------------
   7. VARIANT SYSTEM
   ---------------------------------------------------------- */
function resolveVariant() {
  const params = new URLSearchParams(window.location.search);
  const qv = params.get("variant_id");
  if (qv) {
    LP_CONFIG.variant_id = qv;
    localStorage.setItem("lp_variant", qv);
  } else {
    const stored = localStorage.getItem("lp_variant");
    if (stored) LP_CONFIG.variant_id = stored;
  }
}

/* Map variant names to array indices */
const VARIANT_MAP = {
  "H1_FEAR_VID_CTA1":  { h:0, s:0, cta:0, micro:0 },
  "H2_POWER_IMG_CTA2": { h:1, s:1, cta:1, micro:1 },
  "H3_OWNER_VID_CTA3": { h:2, s:2, cta:2, micro:2 },
  "H4_PSYCH_VID_CTA1": { h:3, s:3, cta:0, micro:0 },
  "H5_LORE_VID_CTA3":  { h:4, s:4, cta:2, micro:2 },
  "H6_COMP_IMG_CTA4":  { h:5, s:5, cta:3, micro:3 },
};

function getVariantIndices() {
  return VARIANT_MAP[LP_CONFIG.variant_id] || VARIANT_MAP["H1_FEAR_VID_CTA1"];
}

/* ----------------------------------------------------------
   8. RENDER COPY (called on language change)
   ---------------------------------------------------------- */
function renderCopy() {
  const vi = getVariantIndices();
  const t  = key => getT(key);

  /* Hero */
  const hl = document.getElementById("hero-headline");
  const sh = document.getElementById("hero-subhead");
  if (hl) hl.textContent = (COPY[currentLang]?.headlines || COPY["en-GB"].headlines)[vi.h];
  if (sh) sh.textContent = (COPY[currentLang]?.subheads  || COPY["en-GB"].subheads)[vi.s];

  /* CTA buttons */
  const ctaText  = (COPY[currentLang]?.ctas      || COPY["en-GB"].ctas)[vi.cta];
  const microText = (COPY[currentLang]?.microcopy || COPY["en-GB"].microcopy)[vi.micro];
  document.querySelectorAll(".cta-btn-text").forEach(el => el.textContent = ctaText);
  document.querySelectorAll(".cta-microcopy").forEach(el => el.textContent = microText);

  /* Eligibility bar */
  const bar = document.getElementById("eligibility-bar");
  if (bar) bar.textContent = t("nav.eligibility");

  /* Bullets */
  const bullets = COPY[currentLang]?.bullets || COPY["en-GB"].bullets;
  document.querySelectorAll(".bullet-item").forEach((el, i) => {
    if (!bullets[i]) return;
    el.querySelector(".bullet-icon").textContent = bullets[i].icon;
    el.querySelector(".bullet-title").textContent = bullets[i].title;
    el.querySelector(".bullet-body").textContent  = bullets[i].body;
  });

  /* Steps */
  const steps = COPY[currentLang]?.steps || COPY["en-GB"].steps;
  const note  = COPY[currentLang]?.steps_note || COPY["en-GB"].steps_note;
  document.querySelectorAll(".step-item").forEach((el, i) => {
    if (!steps[i]) return;
    el.querySelector(".step-num").textContent   = steps[i].n;
    el.querySelector(".step-title").textContent = steps[i].title;
    el.querySelector(".step-desc").textContent  = steps[i].desc;
  });
  const noteEl = document.getElementById("steps-note");
  if (noteEl) noteEl.textContent = note;

  /* Modules */
  const modules = COPY[currentLang]?.modules || COPY["en-GB"].modules;
  document.querySelectorAll(".narrative-module").forEach((el, i) => {
    const m = modules[i];
    if (!m) return;
    el.querySelector(".mod-eyebrow").textContent  = m.eyebrow;
    el.querySelector(".mod-headline").textContent = m.headline;
    const lines = el.querySelectorAll(".mod-line");
    lines.forEach((ln, j) => { if (m.lines[j]) ln.textContent = m.lines[j]; });
  });

  /* Requirements */
  const reqs = COPY[currentLang]?.requirements || COPY["en-GB"].requirements;
  document.querySelectorAll(".req-item").forEach((el, i) => {
    if (!reqs[i]) return;
    el.querySelector(".req-label").textContent = reqs[i].label;
    el.querySelector(".req-value").textContent = reqs[i].value;
  });

  /* First session bullets */
  const sess = COPY[currentLang]?.first_session || COPY["en-GB"].first_session;
  document.querySelectorAll(".session-item").forEach((el, i) => {
    if (sess[i]) el.textContent = sess[i];
  });

  /* FAQ */
  const faqs = COPY[currentLang]?.faqs || COPY["en-GB"].faqs;
  document.querySelectorAll(".faq-item").forEach((el, i) => {
    const faq = faqs[i];
    if (!faq) return;
    el.querySelector(".faq-question").textContent = faq.q;
    el.querySelector(".faq-answer").textContent   = faq.a;
  });

  /* Fallback screen */
  const ft = document.getElementById("fallback-title");
  const fb = document.getElementById("fallback-body");
  if (ft) ft.textContent = t("fallback_title");
  if (fb) fb.textContent = t("fallback_body");

  /* Geo block */
  const gbt = document.getElementById("geo-block-title");
  const gbb = document.getElementById("geo-block-body");
  const gbc = document.getElementById("geo-confirm-btn");
  if (gbt) gbt.textContent = t("geo_block_title");
  if (gbb) gbb.textContent = t("geo_block_body");
  if (gbc) gbc.textContent = t("geo_confirm_btn");

  /* Gallery alts */
  const alts = COPY["en-GB"].gallery_alt;
  document.querySelectorAll(".gallery-img").forEach((el, i) => {
    if (alts[i]) el.alt = alts[i];
  });
}

/* ----------------------------------------------------------
   9. HERO VIDEO
   ---------------------------------------------------------- */
function initHeroVideo() {
  const video  = document.getElementById("hero-video");
  const poster = document.getElementById("hero-poster-fallback");
  const playBtn = document.getElementById("hero-play-btn");
  if (!video) return;

  // Set sources from config
  const mp4 = video.querySelector("source[type='video/mp4']");
  const webm = video.querySelector("source[type='video/webm']");
  if (mp4)  mp4.src  = LP_CONFIG.hero_video_mp4;
  if (webm && LP_CONFIG.hero_video_webm) webm.src = LP_CONFIG.hero_video_webm;
  video.poster = LP_CONFIG.hero_poster_webp;

  // If config prefers static poster, skip autoplay
  if (LP_CONFIG.hypotheses.hero_media === "poster") {
    video.style.display = "none";
    if (poster) poster.style.display = "block";
    return;
  }

  let started = false;
  let prog = { 25:false, 50:false, 75:false, 100:false };

  video.addEventListener("play", () => {
    if (!started) { started = true; emit("video_start", { variant_id: LP_CONFIG.variant_id }); }
  });

  video.addEventListener("timeupdate", () => {
    if (!video.duration) return;
    const pct = (video.currentTime / video.duration) * 100;
    for (const milestone of [25,50,75,100]) {
      if (!prog[milestone] && pct >= milestone) {
        prog[milestone] = true;
        emit("video_progress", { percent: milestone, variant_id: LP_CONFIG.variant_id });
      }
    }
  });

  // Autoplay attempt
  const playPromise = video.play();
  if (playPromise !== undefined) {
    playPromise.catch(() => {
      // Autoplay blocked → show play button overlay
      if (poster) poster.style.display = "flex";
      if (playBtn) {
        playBtn.style.display = "flex";
        playBtn.addEventListener("click", () => {
          video.play();
          if (poster) poster.style.display = "none";
          playBtn.style.display = "none";
        });
      }
    });
  }
}

/* ----------------------------------------------------------
   10. CTA BUTTON SETUP
   ---------------------------------------------------------- */
function initCTAs(geoAllowed, osAllowed) {
  const steamUrl = buildSteamLink(LP_CONFIG.variant_id);

  document.querySelectorAll(".cta-btn").forEach(btn => {
    if (geoAllowed && osAllowed) {
      btn.removeAttribute("disabled");
      btn.classList.remove("cta-disabled");
      btn.setAttribute("href", steamUrl);
      btn.setAttribute("target", "_blank");
      btn.setAttribute("rel", "noopener noreferrer");
      btn.addEventListener("click", (e) => {
        const placement = btn.dataset.placement || "unknown";
        emit("steam_click", {
          variant_id:  LP_CONFIG.variant_id,
          placement,
          geo_allowed: geoAllowed,
          os_allowed:  osAllowed,
          url:         steamUrl,
        });
      });
    } else {
      btn.setAttribute("disabled", "true");
      btn.setAttribute("aria-disabled", "true");
      btn.classList.add("cta-disabled");
      btn.removeAttribute("href");
    }
  });
}

/* ----------------------------------------------------------
   11. GEO GATE UI
   ---------------------------------------------------------- */
function buildGeoSelector() {
  const select = document.getElementById("geo-select");
  if (!select) return;
  select.innerHTML = `<option value="">${getT("geo_select_placeholder")}</option>`;
  for (const code of ALLOWED_GEOS) {
    const opt = document.createElement("option");
    opt.value = code;
    opt.textContent = GEO_NAMES[code] || code;
    select.appendChild(opt);
  }
}

function showGeoBlock() {
  const overlay = document.getElementById("geo-block");
  if (overlay) {
    overlay.hidden = false;
    overlay.setAttribute("aria-hidden", "false");
  }
  buildGeoSelector();

  const confirmBtn = document.getElementById("geo-confirm-btn");
  const select     = document.getElementById("geo-select");
  if (!confirmBtn || !select) return;

  confirmBtn.addEventListener("click", () => {
    const chosen = select.value;
    if (!chosen) return;
    localStorage.setItem("lp_geo", chosen);
    const allowed = ALLOWED_GEOS.includes(chosen);
    if (overlay) {
      overlay.hidden = true;
      overlay.setAttribute("aria-hidden", "true");
    }
    const os = detectOS();
    const osOk = (os === "windows");
    emit("eligibility_result", { geo_code: chosen, geo_allowed: allowed, os, os_allowed: osOk, reason: "manual_selection" });
    initCTAs(allowed, osOk);
    if (!allowed) showGeoDisallowedMsg();
  });
}

function showGeoDisallowedMsg() {
  document.querySelectorAll(".geo-disallowed-msg").forEach(el => {
    el.hidden = false;
    el.setAttribute("aria-hidden", "false");
  });
}

/* ----------------------------------------------------------
   12. NON-WINDOWS FALLBACK
   ---------------------------------------------------------- */
function showNonWindowsFallback() {
  const main     = document.getElementById("main-content");
  const fallback = document.getElementById("non-windows-fallback");
  if (main)     main.setAttribute("aria-hidden", "true");
  if (fallback) {
    fallback.hidden = false;
    fallback.setAttribute("aria-hidden", "false");
  }

  // Copy link button
  const copyBtn = document.getElementById("fallback-copy-btn");
  if (copyBtn) {
    copyBtn.addEventListener("click", () => {
      navigator.clipboard?.writeText(window.location.href).then(() => {
        copyBtn.textContent = "Copied!";
        setTimeout(() => copyBtn.textContent = getT("fallback_copy_btn"), 2000);
      });
    });
  }

  // QR code (optional)
  if (LP_CONFIG.enable_qr) {
    const qrContainer = document.getElementById("qr-container");
    if (qrContainer) {
      qrContainer.hidden = false;
      renderQR(window.location.href, qrContainer);
    }
  }
}

/* ----------------------------------------------------------
   13. MINIMAL QR CODE GENERATOR (pure JS, no CDN)
   ---------------------------------------------------------- */
function renderQR(url, container) {
  /* Placeholder implementation — replace with a real QR library.
     This outputs a canvas element with a placeholder message.
     Recommended: use qrcodejs or qr-creator loaded locally. */
  const msg = document.createElement("p");
  msg.style.cssText = "font-size:0.75rem;opacity:0.6;margin-top:0.5rem;";
  msg.textContent   = "QR: " + url;
  container.appendChild(msg);
  if (LP_CONFIG.debug) console.info("[LP] QR placeholder rendered. Add a real QR library for production.");
}

/* ----------------------------------------------------------
   14. ACCORDION (FAQ)
   ---------------------------------------------------------- */
function initAccordion() {
  document.querySelectorAll(".faq-item").forEach(item => {
    const btn = item.querySelector(".faq-question-btn");
    const ans = item.querySelector(".faq-answer");
    if (!btn || !ans) return;

    const id = item.dataset.faqId || "unknown";
    btn.setAttribute("aria-expanded", "false");
    ans.setAttribute("aria-hidden", "true");

    btn.addEventListener("click", () => {
      const isOpen = btn.getAttribute("aria-expanded") === "true";
      // Close all
      document.querySelectorAll(".faq-item").forEach(i => {
        i.querySelector(".faq-question-btn")?.setAttribute("aria-expanded","false");
        i.querySelector(".faq-answer")?.setAttribute("aria-hidden","true");
        i.classList.remove("open");
      });
      // Open clicked (toggle)
      if (!isOpen) {
        btn.setAttribute("aria-expanded","true");
        ans.setAttribute("aria-hidden","false");
        item.classList.add("open");
        emit("faq_open", { question_id: id, variant_id: LP_CONFIG.variant_id });
      }
    });

    // Keyboard support
    btn.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); btn.click(); }
    });
  });
}

/* ----------------------------------------------------------
   15. REQUIREMENTS CARD TOGGLE
   ---------------------------------------------------------- */
function initRequirementsToggle() {
  const toggle = document.getElementById("req-toggle");
  const card   = document.getElementById("req-card");
  if (!toggle || !card) return;

  // If hypothesis says show above fold, reveal by default
  if (LP_CONFIG.hypotheses.requirements_visible === "mini_card") {
    card.hidden = false;
  }

  toggle.addEventListener("click", () => {
    const open = !card.hidden;
    card.hidden = open;
    toggle.setAttribute("aria-expanded", !open);
    toggle.textContent = open ? "▶ System Requirements" : "▼ System Requirements";
  });
}

/* ----------------------------------------------------------
   16. WEB VITALS (best-effort PerformanceObserver)
   ---------------------------------------------------------- */
function initWebVitals() {
  try {
    // LCP
    const lcp = new PerformanceObserver(list => {
      const entries = list.getEntries();
      const last = entries[entries.length - 1];
      emit("web_vitals", { metric: "LCP", value: last.startTime });
    });
    lcp.observe({ type: "largest-contentful-paint", buffered: true });

    // CLS
    let clsVal = 0;
    const cls = new PerformanceObserver(list => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) clsVal += entry.value;
      }
      emit("web_vitals", { metric: "CLS", value: clsVal });
    });
    cls.observe({ type: "layout-shift", buffered: true });

    // INP (Event Timing)
    const inp = new PerformanceObserver(list => {
      for (const entry of list.getEntries()) {
        if (entry.duration > 40) {
          emit("web_vitals", { metric: "INP_candidate", value: entry.duration });
        }
      }
    });
    inp.observe({ type: "event", buffered: true, durationThreshold: 40 });
  } catch (e) {
    if (LP_CONFIG.debug) console.warn("[LP] PerformanceObserver not fully supported:", e.message);
  }
}

/* ----------------------------------------------------------
   17. LANGUAGE SWITCHER INIT
   ---------------------------------------------------------- */
function initLangSwitcher() {
  document.querySelectorAll(".lang-btn").forEach(btn => {
    btn.addEventListener("click", () => setLanguage(btn.dataset.lang));
    btn.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setLanguage(btn.dataset.lang); }
    });
  });
  // Restore saved preference
  const saved = localStorage.getItem("lp_lang");
  if (saved && LP_CONFIG.supported_languages.includes(saved)) {
    currentLang = saved;
    document.documentElement.lang = saved;
  }
}

/* ----------------------------------------------------------
   18. SCROLL ANIMATIONS (CSS-class driven, minimal JS)
   ---------------------------------------------------------- */
function initScrollReveal() {
  if (!("IntersectionObserver" in window)) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add("revealed");
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll(".reveal").forEach(el => io.observe(el));
}

/* ----------------------------------------------------------
   19. BOOTSTRAP
   ---------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  resolveVariant();
  initLangSwitcher();
  renderCopy();

  const geo = detectGeo();
  const os  = detectOS();
  const osAllowed  = (os === "windows");
  const geoAllowed = geo ? ALLOWED_GEOS.includes(geo) : null; // null = unknown

  emit("page_view", {
    variant_id:  LP_CONFIG.variant_id,
    lang:        currentLang,
    geo:         geo || "unknown",
    os,
    geo_allowed: geoAllowed,
    os_allowed:  osAllowed,
  });

  emit("eligibility_result", {
    geo_code:    geo || "unknown",
    geo_allowed: geoAllowed,
    os,
    os_allowed:  osAllowed,
    reason:      geo ? "server_hint_or_cache" : "unknown",
  });

  // OS gate
  if (!osAllowed) {
    showNonWindowsFallback();
    initCTAs(false, false);
  } else if (geoAllowed === null) {
    // Unknown GEO → require manual selection
    showGeoBlock();
    initCTAs(false, false);
  } else if (!geoAllowed) {
    showGeoDisallowedMsg();
    initCTAs(false, false);
  } else {
    initCTAs(true, true);
  }

  initHeroVideo();
  initAccordion();
  initRequirementsToggle();
  initScrollReveal();
  initWebVitals();

  // Build asset URLs from config
  const heroVideo = document.getElementById("hero-video");
  if (heroVideo) heroVideo.poster = LP_CONFIG.hero_poster_webp;

  // Gallery images
  const imgs = document.querySelectorAll(".gallery-img");
  const srcs = [LP_CONFIG.screenshot_1_webp, LP_CONFIG.screenshot_2_webp, LP_CONFIG.screenshot_3_webp];
  imgs.forEach((img, i) => { if (srcs[i]) img.src = srcs[i]; });

  if (LP_CONFIG.debug) console.info("[LP] Bootstrap complete. Variant:", LP_CONFIG.variant_id);
});
