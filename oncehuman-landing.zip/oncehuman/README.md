# Once Human — Conversion Landing Page

**Version:** 1.0.0  
**Build type:** Static (no build tools required)  
**Target:** Cold-traffic paid acquisition → Steam install → in-game "Create Role"

---

## What This Project Is

A production-ready, conversion-focused landing page for the free-to-play PC survival game **Once Human** (Steam). The page is optimised for cold paid traffic and targets the following funnel:

```
Ad click → Landing page → Steam store → Install → Launch → Create Role ✓
```

Every design and copy decision is made to reduce drop-off at each stage. The page includes:

- Geo + OS eligibility gating (disables CTA for ineligible users)
- A/B variant system (6 headline / subhead / CTA variants)
- Full event tracking via `window.dataLayer` (no external scripts required)
- Honest disclosures (free-to-play, optional purchases, chance-based mechanics, online play)
- British English copy with DE and FR localisation stubs

---

## How to Run Locally

No build step required.

**Option 1 — Direct file open:**
```
Open index.html in your browser.
```

**Option 2 — Local server (recommended; avoids video CORS issues):**
```bash
# Python 3
python3 -m http.server 8080
# Then open http://localhost:8080
```

**Option 3 — VS Code Live Server extension:**
Install the "Live Server" extension, right-click `index.html` → "Open with Live Server".

### Debug mode

In `app.js`, set `debug: true` in `LP_CONFIG` (it is `true` by default). All events will log to the browser console under `[LP]`.

---

## Assets Needed — MUST PROVIDE BEFORE GOING LIVE

Replace all placeholder URLs in `app.js` → `LP_CONFIG` and in `index.html` `<link rel="preload">` / `<meta og:image>`.

### Hero video
| Asset | Spec |
|-------|------|
| `hero-loop.mp4` | H.264 baseline, 6–12 s loop, muted, 16:9, ≤ 8 MB recommended |
| `hero-loop.webm` | VP9 or AV1, same duration (optional but recommended for smaller size) |
| `hero-poster.webp` | 1920 × 1080, WebP or AVIF, shown instantly before video loads |

**Hook cut suggestions (choose one per variant):**
1. **Fear-first:** creature reveal → impact moment → title/CTA card
2. **Power-first:** weapon burst → boss reaction → title/CTA card
3. **Ownership-first:** territory montage → co-op moment → eerie vista → title/CTA card

### Screenshots (3 required, 4 srcset widths each)
| Shot | Composition | Srcset widths needed |
|------|-------------|----------------------|
| `shot-threat` | Creature/boss + player silhouette; high contrast | 640w, 960w, 1280w, 1920w |
| `shot-territory` | Base/territory overview; clean readable composition | 640w, 960w, 1280w, 1920w |
| `shot-crafting` | Weapon or crafting UI; dynamic, readable | 640w, 960w, 1280w, 1920w |

Provide each as **WebP** (preferred) or AVIF. Include JPEG/PNG as `<source>` fallback if needed.

### Narrative module images (3 required)
Used inside the narrative section. 800 × 450 px minimum. Loading is lazy.
- Module A (Hook): contaminated atmosphere / environment shot
- Module B (Curiosity): creature or boss encounter
- Module C (Solution): base + weapons / co-op moment

### Logo (optional)
A game logo (WebP/PNG, transparent background) can be added to the utility bar or hero area by inserting an `<img>` in `#utility-bar` and updating the hero eyebrow.

---

## Affiliate / Tracking Parameters — WHERE TO INSERT

### In `app.js → LP_CONFIG`:

```js
affiliate_base_link:      "https://YOUR_TRACKING_DOMAIN/click?offer=oncehuman&dest=steam",
affiliate_click_id_param: "subid",  // ← change to your network's click ID param name
```

Common affiliate click ID param names by network:
| Network | Param name |
|---------|-----------|
| Impact Radius | `irclickid` |
| CJ Affiliate | `cjclickid` |
| ClickBank | `hop` |
| Custom | `s1`, `subid`, `aff_sub`, `tid`, `clickid` |

### Postback / server-side tracking:

**IMPORTANT:** This file does NOT configure any server-side postback. The affiliate click ID is simply passed through to the Steam/tracking URL as a query parameter. To attribute conversions (Steam installs or in-game "Create Role" events), you must:

1. Configure your affiliate network's server-to-server postback URL in the network dashboard.
2. Receive the `conversion` event from your tracking domain (or from Steam's affiliate programme if applicable).
3. Fire the postback with the stored click ID.

Consult your affiliate network's documentation for postback setup. This landing page has no server-side component.

---

## A/B Testing

### Variant naming scheme
```
H<headline_idx>_<hook>_<media>_CTA<cta_idx>
```
Examples:
- `H1_FEAR_VID_CTA1` — Headline 1, fear hook, video hero, CTA 1
- `H2_POWER_IMG_CTA2` — Headline 2, power hook, static poster, CTA 2
- `H3_OWNER_VID_CTA3` — Headline 3, ownership hook, video hero, CTA 3

### Activating a variant
**Via URL:** `https://yourdomain.com/?variant_id=H2_POWER_IMG_CTA2`  
**Via config:** Set `variant_id` in `LP_CONFIG` in `app.js`.  
**Persistent:** variant_id is saved to `localStorage` on first load.

### 5 Prioritised Hypotheses
| # | Hypothesis | Toggle in `LP_CONFIG.hypotheses` | Metric to watch |
|---|-----------|----------------------------------|-----------------|
| 1 | **Hook angle** — fear vs power vs ownership | `hook_angle: "fear" \| "power" \| "ownership"` | LP→Steam CTR |
| 2 | **Hero media** — video loop vs static poster | `hero_media: "video" \| "poster"` | LCP, engagement time |
| 3 | **CTA copy** — "Play on Steam" vs "Install via Steam" vs "Start Survival" | `cta_copy_index: 0–5` | CTA click rate |
| 4 | **3-step strip position** — above fold vs below first scroll | `strip_position: "above_fold" \| "below_scroll"` | Scroll depth |
| 5 | **Requirements visibility** — mini-card vs FAQ only | `requirements_visible: "mini_card" \| "faq_only"` | Drop-off at Steam |

---

## Event Tracking Reference

Events are pushed to `window.dataLayer` and dispatched as `CustomEvent('lp_event')`. Connect your analytics layer (GTM, Segment, custom) by listening:

```js
document.addEventListener('lp_event', e => {
  console.log(e.detail); // { event, ts, ...payload }
});
```

| Event name | Key payload fields |
|------------|-------------------|
| `page_view` | `variant_id, lang, geo, os, geo_allowed, os_allowed` |
| `video_start` | `variant_id` |
| `video_progress` | `percent (25/50/75/100), variant_id` |
| `steam_click` | `variant_id, placement, geo_allowed, os_allowed, url` |
| `eligibility_result` | `geo_code, geo_allowed, os, os_allowed, reason` |
| `faq_open` | `question_id, variant_id` |
| `web_vitals` | `metric (LCP/CLS/INP_candidate), value` |

---

## GEO Detection Logic

```
1. Read <meta name="x-geo-country" content="__GEO_COUNTRY__"> (server-injected)
2. Read window.__GEO_COUNTRY (JS-injected before app.js)
3. Read localStorage['lp_geo'] (cached manual selection)
4. If none → show country selector (only allowed GEOs listed)
```

**Allowed GEOs:** DE, FR, GB, AU, NL, AT, NO, CH, NZ, CA, US

---

## 7-Day Build & Test Timeline

| Day | Task |
|-----|------|
| **Day 1** | Set up hosting/CDN. Obtain and optimise all video + screenshot assets. Insert real asset URLs into `LP_CONFIG`. |
| **Day 2** | Insert affiliate base link + correct `affiliate_click_id_param`. Test UTM passthrough manually. Confirm Steam link opens in new tab. |
| **Day 3** | Configure server-side GEO injection (`x-geo-country` meta tag). Test all GEO states: allowed, disallowed, unknown. |
| **Day 4** | Connect `window.dataLayer` events to your analytics (GTM or custom). Verify all 7 event types fire correctly. Set up conversion goal for Steam click. |
| **Day 5** | Cross-browser + device testing: Chrome, Firefox, Safari (macOS), Edge. Mobile fallback screen. Check accessibility: keyboard nav, ARIA, focus states. |
| **Day 6** | Performance audit: Lighthouse, WebPageTest on simulated slow 3G. Target LCP ≤ 2.5 s. Inline critical CSS if needed. Optimise images to WebP/AVIF. |
| **Day 7** | A/B test setup: configure 2 variants (e.g. H1_FEAR_VID_CTA1 vs H2_POWER_IMG_CTA2) via URL params or split-testing tool. Launch with traffic cap for initial validation. |

---

## QA Checklist & Acceptance Criteria

### Rendering
- [ ] Hero poster appears immediately (≤ 200 ms on fast connection)
- [ ] Video autoplays muted on desktop Chrome/Edge; poster shown on Safari with autoplay blocked
- [ ] "Play preview" button appears and works when autoplay is blocked
- [ ] All 3 gallery images lazy-load and display correctly
- [ ] Page renders correctly at 375px, 768px, 1280px, 1920px

### Eligibility gating
- [ ] **GEO allowed + Windows** → CTA enabled, links to Steam/affiliate URL in new tab
- [ ] **GEO disallowed** → CTA disabled, disallowed message shown
- [ ] **GEO unknown** → country selector shown; selecting allowed GEO enables CTA
- [ ] **Non-Windows OS** → non-Windows fallback screen shown; CTA hidden
- [ ] "Copy link" button on fallback screen copies current URL to clipboard

### CTA / Links
- [ ] All CTAs open in `target="_blank" rel="noopener noreferrer"`
- [ ] UTM params from inbound URL are appended to outbound Steam URL
- [ ] `variant_id` is appended to outbound Steam URL
- [ ] Affiliate click ID param is appended when present in inbound URL

### Tracking
- [ ] `page_view` fires on load with correct `variant_id`, `geo`, `os`
- [ ] `steam_click` fires on each CTA click with `placement` field
- [ ] `faq_open` fires when any FAQ is expanded
- [ ] `web_vitals` fires LCP value (check DevTools console in debug mode)

### Accessibility
- [ ] All interactive elements reachable and operable via keyboard (Tab / Enter / Space)
- [ ] FAQ accordion: `aria-expanded` toggles correctly
- [ ] `aria-hidden="true"` on decorative elements
- [ ] Visible focus indicators on all controls
- [ ] Colour contrast passes WCAG AA for body text on background

### Localisation
- [ ] EN → DE → FR language switch updates all visible strings
- [ ] Language preference persists across page reload (localStorage)
- [ ] Strings missing in DE/FR gracefully fall back to EN

### Performance
- [ ] Lighthouse Performance score ≥ 80 on desktop (target)
- [ ] LCP ≤ 2.5 s on simulated Fast 3G (Lighthouse throttled)
- [ ] CLS < 0.1 (all media has explicit `width`/`height` or `aspect-ratio`)
- [ ] No render-blocking JS (app.js loaded with `defer`)

---

## File Structure

```
oncehuman/
├── index.html   — Single-page HTML; semantic structure; no framework
├── styles.css   — All styles; CSS variables; responsive; print-safe
├── app.js       — Config, copy variants, gating, tracking, accordion
└── README.md    — This file
```

---

## Legal Notes

- This landing page is an **independent promotional page** and must not imply official affiliation with Valve Corporation or the Once Human developers (Starry Studio / NetEase).
- Ensure your affiliate agreement permits the disclosures and copy used.
- In-game purchase disclosure (including chance-based mechanics) is included in the FAQ and footer to meet regulatory requirements in applicable GEOs.
- If running ads into AU or NZ, verify compliance with local gambling/loot box guidance.

---

*Generated for: Once Human Steam affiliate landing page · Production build v1.0*
